------------------------------------
installation and un-installation
------------------------------------
copy the files to your darkness directory, run the configuration program 
depending on your os.  lemon32.exe and lemcfg32.exe.(win32) lemon.exe and lemcfg.exe (dos)
DO NOT PUT IT IN IT'S OWN DIRECTORY!!!  there seems to be an issue with darkness not reading the lemon.dat file
in the win32 version so after it is installed remove the path in lemon.dat it's has to do with an older version
of xdoor being used in darkness i beleive.

If at some point you need to remove
the igm you can run the config program to un install it. Win32 users 