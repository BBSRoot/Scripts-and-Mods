                                          ___              
                             ,----.     ,--.'|_            
                            /   /  \-.  |  | :,'   __  ,-. 
                 ,--,  ,--,|   :    :|  :  : ' : ,' ,'/ /| 
                 |'. \/ .`||   | .\  ..;__,'  /  '  | |' | 
                 '  \/  / ;.   ; |:  ||  |   |   |  |   ,' 
                  \  \.' / '   .  \  |:__,'| :   '  :  /   
                   \  ;  ;  \   `.   |  '  : |__ |  | '    
                  / \  \  \  `--'""| |  |  | '.'|;  : |    
                ./__;   ;  \   |   | |  ;  :    ;|  , ;    
                |   :/\  \ ;   |   | :  |  ,   /  ---'     
                `---'  `--`    `---'.|   ---`-'            
                                 `---`                                  05/2017
 ------------------------------------------------------------------------------

                                TDF Preview
                               First Release
                          for Raspberry Pi Systems
                                
Software --------------------------------------------------------------------
       [ ] PCB PPe      [ ] OBV          [ ] VGA         [x] OTHER Program___
       [ ] Renegade     [ ] Iiniquity    [ ] ASCII       [ ] HTML/CGI/WWW    
       [ ] Mystic       [ ] WWVI         [ ] Telegard    [ ] MPL
       [ ] ANSI         [ ] TEXT
OS --------------------------------------------------------------------------
    [ ] dos  [ ] os/2  [ ] windows [ ] Win32 [x] *nix [x] RPI Linux
Type ------------------------------------------------------------------------
                infoform [ ]   utility [ ]  misc [x]  door [ ]
                
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
                  ____  _           __      _                    
                 / __ \(_)_________/ /___ _(_)___ ___  ___  _____
                / / / / / ___/ ___/ / __ `/ / __ `__ \/ _ \/ ___/
               / /_/ / (__  ) /__/ / /_/ / / / / / / /  __/ /    
              /_____/_/____/\___/_/\__,_/_/_/ /_/ /_/\___/_/     

   The author has taken every precaution to insure that no harm or damage
will occur on computer systems operating this util.  Never the less, the
author will NOT be held liable for whatever may happen on your computer
system or to any computer systems which connects to your own as a result of
operating this util.  The user assumes full responsibility for the correct
operation of this software package, whether harm or damage results from
software error, hardware malfunction, or operator error.  NO warranties are
offered, expressly stated or implied, including without limitation or
restriction any warranties of operation for a particular purpose and/or
merchant ability.  If you do not agree with this then do NOT use this
program.

                         
-------------------------------------------------------------------------------
                ____                      _       __  _           
               / __ \___  _______________(_)___  / /_(_)___  ____ 
              / / / / _ \/ ___/ ___/ ___/ / __ \/ __/ / __ \/ __ \
             / /_/ /  __(__  ) /__/ /  / / /_/ / /_/ / /_/ / / / /
            /_____/\___/____/\___/_/  /_/ .___/\__/_/\____/_/ /_/ 
                                       /_/                       

  A small utility to quick preview TDF Font Files. Very useful, if you are 
makings ANSIs and want to find a Font that matches with your theme.
  
-------------------------------------------------------------------------------
                ____           __        ____      __  _           
               /  _/___  _____/ /_____ _/ / /___ _/ /_(_)___  ____ 
               / // __ \/ ___/ __/ __ `/ / / __ `/ __/ / __ \/ __ \
             _/ // / / (__  ) /_/ /_/ / / / /_/ / /_/ / /_/ / / / /
            /___/_/ /_/____/\__/\__,_/_/_/\__,_/\__/_/\____/_/ /_/ 

.oO No installation is needed.

-------------------------------------------------------------------------------
                           __  __                    
                          / / / /________ _____ ____ 
                         / / / / ___/ __ `/ __ `/ _ \
                        / /_/ (__  ) /_/ / /_/ /  __/
                        \____/____/\__,_/\__, /\___/ 
                                        /____/       

  Specify the input file and the format of it. The options used are as follows:

  Usage: tdfpreview <font_file> <text>
  
  Options:
    <font_file>  : Any .TDF Font File
    <text>       : Text to Preview
  
  Example:
  
    tdfpreview "*.tdf" Hello
    tdfpreview "*.tdf" "C Ya!"

    
-------------------------------------------------------------------------------
            _______                   ____  ___      __                  
           / ____(_)  _____  _____  _/_/ / / (_)____/ /_____  _______  __
          / /_  / / |/_/ _ \/ ___/_/_// /_/ / / ___/ __/ __ \/ ___/ / / /
         / __/ / />  </  __(__  )/_/ / __  / (__  ) /_/ /_/ / /  / /_/ / 
        /_/   /_/_/|_|\___/____/_/  /_/ /_/_/____/\__/\____/_/   \__, /  
                                                                /____/   


.oO First Release... 05/2017

-------------------------------------------------------------------------------
                       ______            __             __ 
                      / ____/___  ____  / /_____ ______/ /_
                     / /   / __ \/ __ \/ __/ __ `/ ___/ __/
                    / /___/ /_/ / / / / /_/ /_/ / /__/ /_  
                    \____/\____/_/ /_/\__/\__,_/\___/\__/  


If you want to send me bug report or a note telling me how much you like it,
please feel free to do so. ;)
   _            _   _              ___          _    _       
  /_\  _ _  ___| |_| |_  ___ _ _  |   \ _ _ ___(_)__| |               8888
 / _ \| ' \/ _ \  _| ' \/ -_) '_| | |) | '_/ _ \ / _` |            8 888888 8
/_/ \_\_||_\___/\__|_||_\___|_|   |___/|_| \___/_\__,_|            8888888888
                                                                   8888888888
         DoNt Be aNoTHeR DrOiD fOR tHe SySteM                      88 8888 88
                                                                   8888888888
    .o HaM RaDiO    .o ANSi ARt!       .o MySTiC MoDS              "88||||88"
    .o NeWS         .o WeATheR         .o FiLEs                     ""8888""
    .o GaMeS        .o TeXtFiLeS       .o PrEPardNeSS                  88
    .o TuTors       .o bOOkS/PdFs      .o SuRVaViLiSM          8 8 88888888888
    .o FsxNet       .o SurvNet         .o More...            888 8888][][][888
                                                               8 888888##88888
   TeLNeT : andr01d.zapto.org:9999 [UTC 11:00 - 20:00]         8 8888.####.888
   SySoP  : xqtr                   eMAiL: xqtr.xqtr@gmail.com  8 8888##88##888



