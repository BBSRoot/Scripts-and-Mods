                                          ___
                             ,----.     ,--.'|_
                            /   /  \-.  |  | :,'   __  ,-.
                 ,--,  ,--,|   :    :|  :  : ' : ,' ,'/ /|
                 |'. \/ .`||   | .\  ..;__,'  /  '  | |' |
                 '  \/  / ;.   ; |:  ||  |   |   |  |   ,'
                  \  \.' / '   .  \  |:__,'| :   '  :  /
                   \  ;  ;  \   `.   |  '  : |__ |  | '
                  / \  \  \  `--'""| |  |  | '.'|;  : |
                ./__;   ;  \   |   | |  ;  :    ;|  , ;
                |   :/\  \ ;   |   | :  |  ,   /  ---'
                `---'  `--`    `---'.|   ---`-'
                                 `---`                                        
 ------------------------------------------------------------------------------

                             TDFStudio 1.3
                            
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
                  ____  _           __      _
                 / __ \(_)_________/ /___ _(_)___ ___  ___  _____
                / / / / / ___/ ___/ / __ `/ / __ `__ \/ _ \/ ___/
               / /_/ / (__  ) /__/ / /_/ / / / / / / /  __/ /
              /_____/_/____/\___/_/\__,_/_/_/ /_/ /_/\___/_/

   The author has taken every precaution to insure that no harm or damage
will occur on computer systems operating this util.  Never the less, the
author will NOT be held liable for whatever may happen on your computer
system or to any computer systems which connects to your own as a result of
operating this util.  The user assumes full responsibility for the correct
operation of this software package, whether harm or damage results from
software error, hardware malfunction, or operator error.  NO warranties are
offered, expressly stated or implied, including without limitation or
restriction any warranties of operation for a particular purpose and/or
merchant ability.  If you do not agree with this then do NOT use this
program.


-------------------------------------------------------------------------------
                ____                      _       __  _
               / __ \___  _______________(_)___  / /_(_)___  ____
              / / / / _ \/ ___/ ___/ ___/ / __ \/ __/ / __ \/ __ \
             / /_/ /  __(__  ) /__/ /  / / /_/ / /_/ / /_/ / / / /
            /_____/\___/____/\___/_/  /_/ .___/\__/_/\____/_/ /_/
                                       /_/

 A small application to preview TDF Font Files in your system, with out the
 need of DosBox and TheDraw. You can also:

.oO Extract Font Sets
.oO Merge Font Files
.oO Create New Fonts
.oO Load external ANSIs and RIP the fonts!!!
.oO Save the displayed text to .ANS file
.oO Change/Write your text to display
.oO Supports files with multiple fonts
.oO Browse easily for files
.oO Change Font Name, Spacing, Type
.oO Preview available characters
.oO Recolor fonts

-------------------------------------------------------------------------------
                ____           __        ____      __  _
               /  _/___  _____/ /_____ _/ / /___ _/ /_(_)___  ____
               / // __ \/ ___/ __/ __ `/ / / __ `/ __/ / __ \/ __ \
             _/ // / / (__  ) /_/ /_/ / / / /_/ / /_/ / /_/ / / / /
            /___/_/ /_/____/\__/\__,_/_/_/\__,_/\__/_/\____/_/ /_/

.oO Just execute the file

-------------------------------------------------------------------------------
           ______            _____                        __  _
          / ____/___  ____  / __(_)___ ___  ___________ _/ /_(_)___  ____
         / /   / __ \/ __ \/ /_/ / __ `/ / / / ___/ __ `/ __/ / __ \/ __ \
        / /___/ /_/ / / / / __/ / /_/ / /_/ / /  / /_/ / /_/ / /_/ / / / /
        \____/\____/_/ /_/_/ /_/\__, /\__,_/_/   \__,_/\__/_/\____/_/ /_/
                               /____/

 You can create an .INI file to specify a directory to search for fonts. This
way it will be easier to browse your font collection. Inside the package/zip 
you will find an example of the ini file. If you omit the ini file, then the
program will always look to your current directory.

          If you enter an invalid directory the program will crash.

-------------------------------------------------------------------------------
                           __  __
                          / / / /________ _____ ____
                         / / / / ___/ __ `/ __ `/ _ \
                        / /_/ (__  ) /_/ / /_/ /  __/
                        \____/____/\__,_/\__, /\___/
                                        /____/

   ./tdfstudio [fontfile]
 
        [fontfile] : FIlename of valid TDF Font File.
 
  If you ommit the filename a list with all files in the current directory will
popup and you can choose from there.

  
  Keys:
  
    Up, Down  : Next/Previous Font in File/Set
    ESC       : Exit
    L         : Load a font file [tdf]
    E         : Extract current selected font to a file
    M         : Merge another Font file to the current file
    C         : Create New Empty TDF File
    S         : Save displayed text as an ANSI File
    T         : Change Text to be displayed
    I         : Change Font Spacing
    N         : Change Font Name
    Y         : Change Font Type
    F         : Change Font Type [Block/Color/Outline]
    X         : Change X Position of the text displayed
    Y         : Change Y Position of the text displayed
    P         : Display how many and which colors are used for current font
    R         : ReColor displayed text with a color you specify
    U         : Substitude Color of X,Y Position
    
    
  For a demo, on how to create a new font, from an ANSI image, watch this
  video: https://www.youtube.com/watch?v=VC9liLWPyoA
 
-------------------------------------------------------------------------------
            _______                   ____  ___      __
           / ____(_)  _____  _____  _/_/ / / (_)____/ /_____  _______  __
          / /_  / / |/_/ _ \/ ___/_/_// /_/ / / ___/ __/ __ \/ ___/ / / /
         / __/ / />  </  __(__  )/_/ / __  / (__  ) /_/ /_/ / /  / /_/ /
        /_/   /_/_/|_|\___/____/_/  /_/ /_/_/____/\__/\____/_/   \__, /
                                                                /____/


.oO First Release...  v1.00 1/2018
.oO Second Release... v1.10 9/2018
    -- Fixed Bugs
    -- Added feature to color font
    -- Added feature to replace specific char/color
    -- GUI elements redesigned
.oO Third Release... v1.3 2/2019
    -- Added feature to create fonts
    -- Added feature to copy font char from image
    -- The app now executes in GUI with SDL2 graphics. It's not a terminal
       app. any more. This way you can have 100% correct ANSI graphics in the
       emulated ANSI screen.
-------------------------------------------------------------------------------
                       ______            __             __
                      / ____/___  ____  / /_____ ______/ /_
                     / /   / __ \/ __ \/ __/ __ `/ ___/ __/
                    / /___/ /_/ / / / / /_/ /_/ / /__/ /_
                    \____/\____/_/ /_/\__/\__,_/\___/\__/


If you want to send me bug report or a note telling me how much you like it,
please feel free to do so. ;) I also accept donations... :)
   _            _   _              ___          _    _
  /_\  _ _  ___| |_| |_  ___ _ _  |   \ _ _ ___(_)__| |               8888
 / _ \| ' \/ _ \  _| ' \/ -_) '_| | |) | '_/ _ \ / _` |            8 888888 8
/_/ \_\_||_\___/\__|_||_\___|_|   |___/|_| \___/_\__,_|            8888888888
                                                                   8888888888
         DoNt Be aNoTHeR DrOiD fOR tHe SySteM                      88 8888 88
                                                                   8888888888
    .o HaM RaDiO    .o ANSi ARt!       .o MySTiC MoDS              "88||||88"
    .o NeWS         .o WeATheR         .o FiLEs                     ""8888""
    .o GaMeS        .o TeXtFiLeS       .o PrEPardNeSS                  88
    .o TuTors       .o bOOkS/PdFs      .o SuRVaViLiSM          8 8 88888888888
    .o FsxNet       .o SurvNet         .o More...            888 8888][][][888
                                                               8 888888##88888
   TeLNeT : andr01d.zapto.org:9999 [UTC 11:00 - 20:00]         8 8888.####.888
   SySoP  : xqtr                   eMAiL: xqtr@gmx.com         8 8888##88##888
   DoNaTe : https://paypal.me/xqtr
