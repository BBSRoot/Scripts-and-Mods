from datetime import datetime, timedelta
from pytz import timezone
import pytz
import time
from dateutil.tz import *
import sys

tt = str(sys.argv[1]).upper()
found=1

for tzn in pytz.all_timezones:
  tzzn = tzn.upper()
  if tt in tzzn:
    found=0
    tz = pytz.timezone(tzn)
    local = tzlocal()
    now=datetime.now()
    now = now.replace(tzinfo = local)
    your_now = now.astimezone(tz)
    #print "%s - %s" % tzn,str(your_now)
    print "%-36s - %-40s" % (tzn,str(your_now))
#"hi there %s" % name

if found == 1:  
  print None

