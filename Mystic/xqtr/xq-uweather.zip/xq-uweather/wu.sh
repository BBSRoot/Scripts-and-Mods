#!/bin/bash


   #This program is free software; you can redistribute it and/or modify
   #it under the terms of the GNU General Public License as published by
   #the Free Software Foundation; either version 2 of the License, or
   #(at your option) any later version.
   
   #This program is distributed in the hope that it will be useful,
   #but WITHOUT ANY WARRANTY; without even the implied warranty of
   #MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   #GNU General Public License for more details.
   
   #You should have received a copy of the GNU General Public License
   #along with this program; if not, write to the Free Software
   #Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
   #MA 02110-1301, USA.



  #Author          : xqtr
  #Date            : 27/01/2017
  #Description     : Displays Weather Information with ANSI graphics from 
  #                  from Weather Underground
  #Version         : 1.0
  #Usage           : ./wu.sh [option]
  
  #Options
  #current : Current Conditions
  #summary : A brief summary of weather
  #today   : Todays weather in general
  #2       : Tomorrows weather in general
  #3       : The day after tommorow weather in general
  #4       : The weather after four days
  
  #Notes:
  #   . Make the script executable
  #   . Make sure you entered a valid API key and City,State information
  #   . Make sure you have the jshon and curl app installed. Install it with:
  #           sudo apt-get install jshon curl
   

#Don't Change!!!
dir="$(dirname "$(readlink -f "$0")")"

#Use your own Key and location
apikey=""
state=""
city=""
lang="EN"

# Text color variables
txtred='\e[0;31m' # red
txtgrn='\e[0;32m' # green
txtylw='\e[0;33m' # yellow
txtblu='\e[0;34m' # blue
txtpur='\e[0;35m' # purple
txtcyn='\e[0;36m' # cyan
txtwht='\e[0;37m' # white
bldred='\e[1;31m' # red - Bold
bldgrn='\e[1;32m' # green
bldylw='\e[1;33m' # yellow
bldblu='\e[1;34m' # blue
bldpur='\e[1;35m' # purple
bldcyn='\e[1;36m' # cyan
bldwht='\e[1;37m' # white
txtund=$(tput sgr 0 1) # Underline
txtbld=$(tput bold) # Bold
txtrst='\e[0m' # Text reset 

function showicon() {
  cat $dir/icons.ans | grep "$1" -m 1 -A 8 -i | tail -n +3
}

#Example for using Colors
#echo -e "${bldylw}   Choose Server to connect...${txtrst}"

#Usefull ANSI Codes
#CSI n A  CUU – Cursor Up
#CSI n B  CUD – Cursor Down
#CSI n C  CUF – Cursor Forward
#CSI n D  CUB – Cursor Back
#CSI n ; m H  CUP – Cursor Position   Moves the cursor to row n column m 

#Check if we have weather information...
if [ ! -e "$dir/forecast.json" ]; then
  curl -Ls -X GET http://api.wunderground.com/api/$apikey/conditions/q/$state/$city.json | sed 's/\/weather\///g' > $dir/forecast.json
  curl -Ls -X GET http://api.wunderground.com/api/$apikey/forecast10day/q/$state/$city.json | sed 's/\/weather\///g' > $dir/forecast10day.json
  curl -Ls -X GET http://api.wunderground.com/api/$apikey/alerts/q/$state/$city.json | sed 's/\/weather\///g' > $dir/alerts.json
else
#...is weather information too old? Update.
  if [ "$(( $(date +"%s") - $(stat -c "%Y" $dir/forecast.json) ))" -gt "7200" ]; then
    curl -Ls -X GET http://api.wunderground.com/api/$apikey/conditions/q/$state/$city.json | sed 's/\/weather\///g' > $dir/forecast.json
    curl -Ls -X GET http://api.wunderground.com/api/$apikey/forecast10day/q/$state/$city.json | sed 's/\/weather\///g' > $dir/forecast10day.json
    curl -Ls -X GET http://api.wunderground.com/api/$apikey/alerts/q/$state/$city.json | sed 's/\/weather\///g' > $dir/alerts.json
  fi
fi
#Is there any weather alert?
isalert=$(cat $dir/alerts.json | jshon -e alerts -a -e wtype_meteoalarm_name -u)
if [[ isalert == "" ]]; then
  rm $dir/alerts.json
fi

if [[ "$1" == "alert" ]]; then
  if [ ! -e "$dir/alerts.json" ]; then
    exit 1
  fi
  data=$(cat "$dir/alerts.json")
  ma_name=$(echo $data | jshon -e alerts -a -e wtype_meteoalarm_name -u)
  ma_level=$(echo $data | jshon -e alerts -a -e level_meteoalarm_name -u)
  ma_desc=$(echo $data | jshon -e alerts -a -e level_meteoalarm_description -u)
  desc=$(echo $data | jshon -e alerts -a -e description -u)
  expire=$(echo $data | jshon -e alerts -a -e expires -u)
  
  echo -e "\e[30G $bldpur MeteoAlarm Info $txtrst"
  echo ""
  echo -e "\e[2G $bldred Alert : $bldwht$ma_name$txtrst"
  echo -e "\e[2G $bldred Level : $bldwht$ma_level$txtrst"
  echo -e "\e[2G $bldred Desc. : $bldwht$ma_desc$txtrst"
  echo ""
  echo -e "\e[26G $bldcyn Weather Underground Info $txtrst"
  echo ""
  echo -e "\e[2G $bldred Expire : $bldwht$expire$txtrst"
  echo -e "\e[2G $bldred Desc.  : $bldwht$desc$txtrst"
  echo -e "\e[2G $bldwht"
  exit 0
fi

if [[ "$1" == "current" ]]; then
  if [ ! -e "$dir/forecast.json" ]; then
    exit 1
  fi
  data=$(cat $dir/forecast.json)
  area=$(echo $data | jshon -e current_observation -e display_location -e full -u)
  icon=$(echo $data | jshon -e current_observation -e icon -u)
  temp=$(echo $data | jshon -e current_observation -e temperature_string -u)
  weather=$(echo $data | jshon -e current_observation -e weather -u)
  feelslike=$(echo $data | jshon -e current_observation -e feelslike_string -u)
  heat=$(echo $data | jshon -e current_observation -e heat_index_string -u)
  wind=$(echo $data | jshon -e current_observation -e wind_string -u)
  humidity=$(echo $data | jshon -e current_observation -e relative_humidity -u)
  pressure_mb=$(echo $data | jshon -e current_observation -e pressure_mb -u)
  dewpoint=$(echo $data | jshon -e current_observation -e dewpoint_string -u)
  windchill=$(echo $data | jshon -e current_observation -e windchill_string -u)
  solar=$(echo $data | jshon -e current_observation -e solarradiation -u)
  precip=$(echo $data | jshon -e current_observation -e precip_today_string -u)
  echo ""
  echo ""
  showicon $icon
  echo -e "\e[7A\e[21G $bldwht Location  : $bldylw$area $txtrst"
  echo -e "\e[21G $bldwht Condition : $bldylw$weather"
  echo -e "\e[21G $bldwht Temp.     : $bldylw$temp"
  echo -e "\e[21G $bldwht Heat Idx. : $bldylw$heat"
  echo -e "\e[21G $bldwht Feels     : $bldylw$feelslike"
  echo -e "\e[21G $bldwht Wind      : $bldylw$wind"
  echo -e "\e[21G $bldwht WindChill : $bldylw$windchill"
  echo -e "\e[21G $bldwht Humidity  : $bldylw$humidity"
  echo -e "\e[21G $bldwht Pressure  : $bldylw$pressure_mb mb"
  echo -e "\e[21G $bldwht Precip.   : $bldylw$precip"
  echo -e "\e[21G $bldwht Dewpoint  : $bldylw$dewpoint"
  echo -e "\e[21G $bldwht Solar     : $bldylw$solar$txtrst"
  echo -e "\e[2G $bldwht"
  exit 0
fi

if [[ "$1" == "summary" ]]; then
  if [ ! -e "$dir/forecast10day.json" ]; then
    exit 1
  fi
  data=$(cat $dir/forecast10day.json)
  icon0=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 0 -e icon -u)
  title0=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 0 -e title -u)
  fcttext_metric0=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 0 -e fcttext_metric -u)

  icon1=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 1 -e icon -u)
  title1=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 1 -e title -u)
  fcttext_metric1=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 1 -e fcttext_metric -u)

  icon2=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 2 -e icon -u)
  title2=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 2 -e title -u)
  fcttext_metric2=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 2 -e fcttext_metric -u)

  icon3=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 3 -e icon -u)
  title3=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 3 -e title -u)
  fcttext_metric3=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 3 -e fcttext_metric -u)

  icon4=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 4 -e icon -u)
  title4=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 4 -e title -u)
  fcttext_metric4=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 4 -e fcttext_metric -u)

  icon5=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 5 -e icon -u)
  title5=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 5 -e title -u)
  fcttext_metric5=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 5 -e fcttext_metric -u)

  icon6=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 6 -e icon -u)
  title6=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 6 -e title -u)
  fcttext_metric6=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 6 -e fcttext_metric -u)

  icon7=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 7 -e icon -u)
  title7=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 7 -e title -u)
  fcttext_metric7=$(echo $data | jshon -e forecast -e txt_forecast -e forecastday -e 7 -e fcttext_metric -u)
  showicon $icon0
  echo -e "\e[4A\e[21G $bldwht Day  : $bldylw$title0 $txtrst"
  echo -e "\e[21G $bldwht Cond.: $bldylw$fcttext_metric0$txtrst"
  showicon $icon1
  echo -e "\e[4A\e[21G $bldwht Day  : $bldylw$title1 $txtrst"
  echo -e "\e[21G $bldwht Cond.: $bldylw$fcttext_metric1$txtrst"
  showicon $icon2
  echo -e "\e[4A\e[21G $bldwht Day  : $bldylw$title2 $txtrst"
  echo -e "\e[21G $bldwht Cond.: $bldylw$fcttext_metric2$txtrst"
  echo -e "\e[2G $bldwht"
  exit 0
fi

if [[ "$1" == "today" ]]; then
  if [ ! -e "$dir/forecast10day.json" ]; then
    exit 1
  fi
  data=$(cat $dir/forecast10day.json)
  day0=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e date -e pretty -u | sed -n 1p)
  wday0=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e date -e weekday_short -u | sed -n 1p)
  high0=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e high -e celsius -u | sed -n 1p)
  low0=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e low -e celsius -u | sed -n 1p)
  conditions0=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e conditions -u | sed -n 1p)
  micon0=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e icon -u | sed -n 1p)
  avewind0=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e avewind -e kph | sed -n 1p)
  dir0=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e avewind -e dir -u | sed -n 1p)
  humidity0=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e avehumidity | sed -n 1p)
  showicon $micon0
  echo -e "\e[6A\e[21G $bldwht $bldylw$wday0 $day0 $txtrst"
  echo ""
  echo -e "\e[21G $bldwht Temperature $txtrst"
  echo -e "\e[21G $bldwht        $txtwht High : $bldred$high0$txtrst"
  echo -e "\e[21G $bldwht        $txtwht Low  : $bldblu$low0$txtrst"
  echo ""
  echo -e "\e[21G $bldwht Condition $txtrst"
  echo -e "\e[21G $bldwht        $bldylw$conditions0$txtrst"
  echo ""
  echo -e "\e[21G $bldwht Wind $txtrst"  
  echo -e "\e[21G $bldwht       $txtwht Ave. Speed : $bldylw$avewind0 Km/h$txtrst"
  echo -e "\e[21G $bldwht       $txtwht Direction  : $bldylw$dir0$txtrst"
  echo ""
  echo -e "\e[21G $bldwht Humidity $txtrst"  
  echo -e "\e[21G $bldwht        $bldylw$humidity0 mb$txtrst"
  echo -e "\e[2G $bldwht"
  exit 0
fi

if [[ "$1" == "2" ]]; then
  if [ ! -e "$dir/forecast10day.json" ]; then
    exit 1
  fi
  data=$(cat $dir/forecast10day.json)
  day1=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e date -e pretty -u | sed -n 2p)
  wday1=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e date -e weekday_short -u | sed -n 2p)
  high1=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e high -e celsius -u | sed -n 2p)
  low1=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e low -e celsius -u | sed -n 2p)
  conditions1=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e conditions -u | sed -n 2p)
  micon1=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e icon -u | sed -n 2p)
  avewind1=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e avewind -e kph | sed -n 2p)
  dir1=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e avewind -e dir -u | sed -n 2p)
  humidity1=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e avehumidity | sed -n 2p)
  showicon $micon1
  echo -e "\e[6A\e[21G $bldwht $bldylw$wday1 $day1 $txtrst"
  echo ""
  echo -e "\e[21G $bldwht Temperature $txtrst"
  echo -e "\e[21G $bldwht        $txtwht High : $bldred$high1$txtrst"
  echo -e "\e[21G $bldwht        $txtwht Low  : $bldblu$low1$txtrst"
  echo ""
  echo -e "\e[21G $bldwht Condition $txtrst"
  echo -e "\e[21G $bldwht        $bldylw$conditions1$txtrst"
  echo ""
  echo -e "\e[21G $bldwht Wind $txtrst"  
  echo -e "\e[21G $bldwht       $txtwht Ave. Speed : $bldylw$avewind1 Km/h$txtrst"
  echo -e "\e[21G $bldwht       $txtwht Direction  : $bldylw$dir1$txtrst"
  echo ""
  echo -e "\e[21G $bldwht Humidity $txtrst"  
  echo -e "\e[21G $bldwht        $bldylw$humidity1 mb$txtrst"
  echo -e "\e[2G $bldwht"
  exit 0
fi

if [[ "$1" == "3" ]]; then
  if [ ! -e "$dir/forecast10day.json" ]; then
    exit 1
  fi
  data=$(cat $dir/forecast10day.json)
  day2=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e date -e pretty -u | sed -n 3p)
  wday2=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e date -e weekday_short -u | sed -n 3p)
  high2=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e high -e celsius -u | sed -n 3p)
  low2=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e low -e celsius -u | sed -n 3p)
  conditions2=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e conditions -u | sed -n 3p)
  micon2=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e icon -u | sed -n 3p)
  avewind2=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e avewind -e kph | sed -n 3p)
  dir2=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e avewind -e dir -u | sed -n 3p)
  humidity2=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e avehumidity | sed -n 3p)
  showicon $micon2
  echo -e "\e[6A\e[21G $bldwht $bldylw$wday2 $day2 $txtrst"
  echo ""
  echo -e "\e[21G $bldwht Temperature $txtrst"
  echo -e "\e[21G $bldwht        $txtwht High : $bldred$high2$txtrst"
  echo -e "\e[21G $bldwht        $txtwht Low  : $bldblu$low2$txtrst"
  echo ""
  echo -e "\e[21G $bldwht Condition $txtrst"
  echo -e "\e[21G $bldwht        $bldylw$conditions2$txtrst"
  echo ""
  echo -e "\e[21G $bldwht Wind $txtrst"  
  echo -e "\e[21G $bldwht       $txtwht Ave. Speed : $bldylw$avewind2 Km/h$txtrst"
  echo -e "\e[21G $bldwht       $txtwht Direction  : $bldylw$dir2$txtrst"
  echo ""
  echo -e "\e[21G $bldwht Humidity $txtrst"  
  echo -e "\e[21G $bldwht        $bldylw$humidity2 mb$txtrst"
  echo -e "\e[2G $bldwht"
  exit 0
fi

if [[ "$1" == "4" ]]; then
  if [ ! -e "$dir/forecast10day.json" ]; then
    exit 1
  fi
  data=$(cat $dir/forecast10day.json)
  day3=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e date -e pretty -u | sed -n 4p)
  wday3=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e date -e weekday_short -u | sed -n 4p)
  high3=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e high -e celsius -u | sed -n 4p)
  low3=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e low -e celsius -u | sed -n 4p)
  conditions3=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e conditions -u | sed -n 4p)
  micon3=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e icon -u | sed -n 4p)
  avewind3=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e avewind -e kph | sed -n 4p)
  dir3=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e avewind -e dir -u | sed -n 4p)
  humidity3=$(echo $data | jshon -e forecast -e simpleforecast -e forecastday -a -e avehumidity | sed -n 4p)
  showicon $micon3
  echo -e "\e[6A\e[21G $bldwht $bldylw$wday3 $day3 $txtrst"
  echo ""
  echo -e "\e[21G $bldwht Temperature $txtrst"
  echo -e "\e[21G $bldwht        $txtwht High : $bldred$high3$txtrst"
  echo -e "\e[21G $bldwht        $txtwht Low  : $bldblu$low3$txtrst"
  echo ""
  echo -e "\e[21G $bldwht Condition $txtrst"
  echo -e "\e[21G $bldwht        $bldylw$conditions3$txtrst"
  echo ""
  echo -e "\e[21G $bldwht Wind $txtrst"  
  echo -e "\e[21G $bldwht       $txtwht Ave. Speed : $bldylw$avewind3 Km/h$txtrst"
  echo -e "\e[21G $bldwht       $txtwht Direction  : $bldylw$dir3$txtrst"
  echo ""
  echo -e "\e[21G $bldwht Humidity $txtrst"  
  echo -e "\e[21G $bldwht        $bldylw$humidity3 mb$txtrst"
  echo -e "\e[2G $bldwht"
  exit 0
fi
