#!/usr/bin/python

#Enter blogname - Example: if blog URL is myblogname.wordpress.com
wp_name = "myblogname"

#The username and password of your account on Wordpress.com
wp_username = "Username"
wp_password = "Password"
