        __  _                        __ _                           _  __
  ______\ \_\\_______________________\///__________________________//_/ /______
  \___\                                                                   /___/
   | .__                                 __                                  |
   | |                   ___  __________/  |________                         |
   |                     \  \/  / ____/\   __\_  __ \                        |
   ;                      >    < <_|  | |  |  |  | \/                        ;
   :                     /__/\_ \__   | |__|  |__|                           :
   .                           \/  |__|      Releases                        .
   .                                                                         .
   :           H/Q Another Droid BBS - andr01d.zapto.org:9999                :
   ;                                                                         ;
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   :                                                                         :
   |                           Ansi tools utility                            |
   :                                                                         :
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   | ._          SoftWare         Oper.System      Type                      |
   ; |           - { } BASH       - {x} Linux      - { } ANSI                ;
   :             - { } DOOR       - {x} RPi        - { } TEXT                :
   .             - { } MPL        - {-} Windows    - {x} ASCII               .
   :             - { } Python     - {-} Mac        - {x} BINARY              :
   ;             - {x} Source     - {-} OS/2                                 ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   |  _     _ _                                                              |
   ; |    _| | |_    ____  _         _     _                                 ;
   :     |_     _|  |    \|_|___ ___| |___|_|_____ ___ ___                   :
   .     |_     _|  |  |  | |_ -|  _| | .'| |     | -_|  _|   _ _ _          .
   ;       |_|_|    |____/|_|___|___|_|__,|_|_|_|_|___|_|    |_|_|_|         ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   ; The author has taken every precaution to insure that no harm or damage  ;
   | will occur on computer systems operating this util.  Never the less, the:
   ; author will NOT be held liable for whatever may happen on your computer .
   : system or to any computer systems which connects to your own as a result:
   . of. operating this util.  The user assumes full responsibility for the  ;
   : correct operation of this software package, whether harm or damage      |
   ; results from software error, hardware malfunction, or operator error.   :
   | NO warranties are : offered, expressly stated or implied, including     .
   | without limitation or ; restriction any warranties of operation for a   :
   ; particular purpose and/or | merchant ability.  If you do not agree with ;
   : this then do NOT use this program.                                      |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´

   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   |        _ _                                                              |
   ;      _| | |_    _____ _           _                                     ;
   :     |_     _|  |  _  | |_ ___ _ _| |_                                   :
   .     |_     _|  |     | . | . | | |  _|   _ _ _                          .
   ;       |_|_|    |__|__|___|___|___|_|    |_|_|_|                         ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   
   Make quick fixes to your ansi files, with out the need of an ansi editor.
   Even with an ansi editor, you can't do easy what ansitool does :p
   
   :: Convert line feeds to Unix <> Windows style
   :: Add/Remove CL and PO pipe codes, for Mystic BBS
   :: Remove annoying SAUCE data, that "break" ansis
   :: Crop screens to 23, 24, 25 lines... easily!!!!

   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   |        _ _                                                              |
   ;      _| | |_    _____         _       _ _                               ;
   :     |_     _|  |     |___ ___| |_ ___| | |                              :
   .     |_     _|  |-   -|   |_ -|  _| .'| | |   _ _ _                      .
   ;       |_|_|    |_____|_|_|___|_| |__,|_|_|  |_|_|_|                     ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´

   No install... 
    

   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   |        _ _                                                              |
   ;      _| | |_    _____         ___ _                                     ;
   :     |_     _|  |     |___ ___|  _|_|___                                 :
   .     |_     _|  |   --| . |   |  _| | . |   _ _ _                        .
   ;       |_|_|    |_____|___|_|_|_| |_|_  |  |_|_|_|                       ;
   |                                    |___|                                |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   
   No config... 
   
   Everything you want, is in the binary help file... just execute the binary
   with no parameters... and pray! mooahahahahahahaahah >:) 

   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   |        _ _                                                              |
   ;      _| | |_    _____ _     _                                           ;
   :     |_     _|  |  |  |_|___| |_ ___ ___ _ _                             :
   .     |_     _|  |     | |_ -|  _| . |  _| | |   _ _ _                    .
   ;       |_|_|    |__|__|_|___|_| |___|_| |_  |  |_|_|_|                   ;
   |                                        |___|                            |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   
    .:. April 2019
     `  + First Release
        
          
   
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
         _____         _   _              ____          _   _ 
        |  _  |___ ___| |_| |_ ___ ___   |    \ ___ ___|_|_| |        8888
        |     |   | . |  _|   | -_|  _|  |  |  |  _| . | | . |     8 888888 8
        |__|__|_|_|___|_| |_|_|___|_|    |____/|_| |___|_|___|     8888888888
                                                                   8888888888
                DoNt Be aNoTHeR DrOiD fOR tHe SySteM               88 8888 88
                                                                   8888888888
 /: HaM RaDiO   /: ANSi ARt!     /: MySTiC MoDS   /: DooRS         '88||||88'
 /: NeWS        /: WeATheR       /: FiLEs         /: SPooKNet       ''8888"'
 /: GaMeS       /: TeXtFiLeS     /: PrEPardNeSS   /: FsxNet            88
 /: TuTors      /: bOOkS/PdFs    /: SuRVaViLiSM   /: ArakNet    8 8 88888888888
                                                              888 8888][][][888
   TeLNeT : andr01d.zapto.org:9999 [UTC 11:00 - 20:00]          8 888888##88888
   SySoP  : xqtr                   eMAiL: xqtr@gmx.com          8 8888.####.888
   DoNaTe : https://paypal.me/xqtr                              8 8888##88##888
