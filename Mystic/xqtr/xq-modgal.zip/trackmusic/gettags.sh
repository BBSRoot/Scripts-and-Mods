#!/bin/bash

extract "$1" > "$2"
sed -i '/^\s*$/d' "$2"
sed -i 's/duration/|15Duration/g' "$2"
sed -i 's/title/|15Title/g' "$2"
sed -i 's/channels/|15Channels/g' "$2"
sed -i 's/sample rate/|15Sample Rate/g' "$2"
sed -i 's/audio depth/|15Bits/g' "$2"
sed -i 's/mimetype/|15MIME/g' "$2"
sed -i 's/created/|15Created/g' "$2"
sed -i 's/format version/|15Version/g' "$2"
sed -i 's/Keywords/|15Tags/g' "$2"
sed -i 's/beats per minute/|15BPM/g' "$2"
sed -i 's/unknown/|15Unkown Tag/g' "$2"
sed -i 's/-/|08-|07/g' "$2"
#Change this to your track music folder
/home/x/mystic/trackmusic/pytag.py "$1" >> "$2"
outp="$(awk 'NF' "$2")"
echo "$outp" > "$2"
sed -i '1d' $2
