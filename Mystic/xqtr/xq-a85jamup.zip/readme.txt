        __  _                        __ _                           _  __
  ______\ \_\\_______________________\///__________________________//_/ /______
  \___\                                                                   /___/
   [ .__                                 __                                  ]
   [ [                   ___  __________/  |________                         ]
   [                     \  \/  / ____/\   __\_  __ \                        ]
   ;                      >    < <_|  | |  |  |  | \/                        ;
   :                     /__/\_ \__   | |__|  |__|                           :
   .                           \/  |__|      Releases                        .
   .                                                                         .
   :           H/Q Another Droid BBS - andr01d.zapto.org:9999                :
   ;                                                                         ;
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   :                                                                         :
   [                ASCII85 - JAM Base Uploader - A85JAMUP                   ]
   :                           BETA Version                       25-06-2018 :
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [ ._          SoftWare         Oper.System      Type                      ]
   ; [           - { } BASH       - {x} Linux      - { } ANSI                ;
   :             - { } DOOR       - {x} RPi        - { } TEXT                :
   .             - { } MPL        - { } Windows    - { } ASCII               .
   :             - { } Python     - { } Mac        - {x} BINARY              :
   ;             - { } Source     - { } OS/2                                 ;
   [                                                                         ]
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [  _     _ _                                                              ]
   ; [    _] ] ]_    ____  _         _     _                                 ;
   :     ]_     _]  ]    \]_]___ ___] ]___]_]_____ ___ ___                   :
   .     ]_     _]  ]  ]  ] ]_ -]  _] ] .'] ]     ] -_]  _]   _ _ _          .
   ;       ]_]_]    ]____/]_]___]___]_]__,]_]_]_]_]___]_]    ]_]_]_]         ;
   [                                                                         ]
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   ; The author has taken every precaution to insure that no harm or damage  ;
   [ will occur on computer systems operating this util.  Never the less, the:
   ; author will NOT be held liable for whatever may happen on your computer .
   : system or to any computer systems which connects to your own as a result:
   . of. operating this util.  The user assumes full responsibility for the  ;
   : correct operation of this software package, whether harm or damage      ]
   ; results from software error, hardware malfunction, or operator error.   :
   [ NO warranties are : offered, expressly stated or implied, including     .
   [ without limitation or ; restriction any warranties of operation for a   :
   ; particular purpose and/or ] merchant ability.  If you do not agree with ;
   : this then do NOT use this program.                                      ]
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [        _ _                                                              ]
   ;      _] ] ]_    _____ _           _                                     ;
   :     ]_     _]  ]  _  ] ]_ ___ _ _] ]_                                   :
   .     ]_     _]  ]     ] . ] . ] ] ]  _]   _ _ _                          .
   ;       ]_]_]    ]__]__]___]___]___]_]    ]_]_]_]                         ;
   [                                                                         ]
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [ Convert binary (or other) files to ASCII85 format and upload/post them  ]
   ; to a JAM Message Base. This way you can share small files with others,  ;
   : without the need of Network MODs to hatch files through the network.    :
   .                                                                         .
     The utility lets you to upload up to 80kb of encoded data and no more,
   . per file. This way it will protect the network from flooding or filling .
   : a message base, with very large files. If you want to share big files,  :
   ; this is not the way. This utility built for the convinience of modders, ;
   [ programmers, artists to share small files.                              ]
   ;                                                                         ;
   . The app. needs some heavy testing!!! Make sure to keep backups of your  .
   : BBS JAM Base files.                                                     :
   ;                                                                         ;
   [                                                                         ]   
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [        _ _                                                              ]
   ;      _] ] ]_    _____         _       _ _                               ;
   :     ]_     _]  ]     ]___ ___] ]_ ___] ] ]                              :
   .     ]_     _]  ]-   -]   ]_ -]  _] .'] ] ]   _ _ _                      .
   ;       ]_]_]    ]_____]_]_]___]_] ]__,]_]_]  ]_]_]_]                     ;
   [                                                                         ]
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [ No installation needed.                                                 ]
   ;                                                                         ;
   :                                                                         :
   .                                                                         .

   .                                                                         .
   :                                                                         :
   ;                                                                         ;
   [                                                                         ]
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [        _ _                                                              ]
   ;      _] ] ]_    _____         ___ _                                     ;
   :     ]_     _]  ]     ]___ ___]  _]_]___                                 :
   .     ]_     _]  ]   --] . ]   ]  _] ] . ]   _ _ _                        .
   ;       ]_]_]    ]_____]___]_]_]_] ]_]_  ]  ]_]_]_]                       ;
   [                                    ]___]                                ]
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [ The app. needs a config file to post the message to a JAM base. This    ]
   ; file is an INI file with the following data:                            ;
   :                                                                         :
   . [main]                                                                  .
     from=                 # User who sends the msg.
     subject=              # This is a prefix. The subject will also contain
                           # the name of the file which is encoded.
     to=                   # Recipient
     origin=               # 10:101/10
     destination=          # 10:101/0
     
   . [jam_base]                                                                        .
   : filename=/home/user/mystic/msgs/fsx_bot.jhr   # The header file of the  :
   ;                                               # JAM Base                ;
   [                                                                         ]
   ; You can make multiple config files and use them with the -C switch to   ;
   : upload files to various Bases/Networks. If you don't provide a config   :
   . file with the -C switch the program will search for the default one,    .
   : which is named a85jamup.ini and is expected to be into the same         :
   ; directory with the app.                                                 ;
   [                                                                         ]   
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [        _ _                                                              ]
   ;      _] ] ]_    _____                                                   ;
   :     ]_     _]  ]  ]  ]___ ___                                           :
   .     ]_     _]  ]  ]  ]_ -] -_]   _ _ _                                  .
   ;       ]_]_]    ]_____]___]___]  ]_]_]_]                                 ;
   [                                                                         ]
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [                                                                         ]
   ; a85Uploader - Ascii85 encode/decode data and upload to JAM Base         ;
   :                                                                         :
   . Usage:                                                                  .
        a85uploader <binary_file> [-c <config_file>] 
        a85uploader -d <encoded_file> <decoded_file> 
     
     Options:  
        Encode file to Ascii85 and upload to a JAM Base. 
     
        -d, /d, --decode    : decode data (encodes by default) 
        -c <config_file>    : use config file 
        -h, /h, --help      : help screen 
     
   .                                                                         .
   :                                                                         :
   ;                                                                         ;
   [                                                                         ]
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [        _ _                                                              ]
   ;      _] ] ]_    _____ _ _                                               ;
   :     ]_     _]  ]   __]_] ]___ ___                                       :
   .     ]_     _]  ]   __] ] ] -_]_ -]   _ _ _                              .
   ;       ]_]_]    ]__]  ]_]_]___]___]  ]_]_]_]                             ;
   [                                                                         ]
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [ a85jamup_l32    # Linux 32bit binary                                    ]
   ; a85jamup_rpi    # RPi binary                                            ;
   : fileid_diz                                                              :
   . readme.txt                                                              .

   .                                                                         .
   :                                                                         :
   ;                                                                         ;
   [                                                                         ]
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [        _ _                                                              ]
   ;      _] ] ]_    _____ _     _                                           ;
   :     ]_     _]  ]  ]  ]_]___] ]_ ___ ___ _ _                             :
   .     ]_     _]  ]     ] ]_ -]  _] . ]  _] ] ]   _ _ _                    .
   ;       ]_]_]    ]__]__]_]___]_] ]___]_] ]_  ]  ]_]_]_]                   ;
   [                                        ]___]                            ]
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [ 25-06-2018 - First Release                                              ]
   ;                                                                         ;
   :                                                                         :
   .                                                                         .

   .                                                                         .
   :                                                                         :
   ;                                                                         ;
   [                                                                         ]
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [        _ _                                                              ]
   ;      _] ] ]_    _____           _ _ _                                   ;
   :     ]_     _]  ]     ]___ ___ _] ]_] ]_ ___                             :
   .     ]_     _]  ]   --]  _] -_] . ] ]  _]_ -]   _ _ _                    .
   ;       ]_]_]    ]_____]_] ]___]___]_]_] ]___]  ]_]_]_]                   ;
   [                                                                         ]
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [ Credits goes to...                                                      ]
   ;   ... the FPC team .... g00r00 ... some guy called Mark May who built   ;
   : a Pascal lib, with awesome stuff... and of course to all BBS lovers     :
   . out there!!! :-x                                                        .

   .                                                                         .
   :                                                                         :
   ;                                                                         ;
   [                                                                         ]
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [        _ _                                                              ]
   ;      _] ] ]_    _____         _           _                             ;
   :     ]_     _]  ]     ]___ ___] ]_ ___ ___] ]_                           :
   .     ]_     _]  ]   --] . ]   ]  _] .']  _]  _]   _ _ _                  .
   ;       ]_]_]    ]_____]___]_]_]_] ]__,]___]_]    ]_]_]_]                 ;
   [                                                                         ]
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   [ ._                                                                   _, ]
   ; [        _____         _   _              ____          _   _         ] ;
   :         ]  _  ]___ ___] ]_] ]_ ___ ___   ]    \ ___ ___]_]_] ]          :
   .         ]     ]   ] . ]  _]   ] -_]  _]  ]  ]  ]  _] . ] ] . ]          .
   '         ]__]__]_]_]___]_] ]_]_]___]_]    ]____/]_] ]___]_]___]          '
                     DoNt Be aNoTHeR DrOiD fOR tHe SySteM                     
                                                                             '
   `  /: HaM RaDiO     /: ANSi ARt!       /: MySTiC MoDS     /: DooRS         
      /: NeWS          /: WeATheR         /: FiLEs           /: SPooKNet     `
   '  /: GaMeS         /: TeXtFiLeS       /: PrEPardNeSS     /: FsxNet       '
      /: TuTors        /: bOOkS/PdFs      /: SuRVaViLiSM     /: ArakNet       
   .                                                                         .
   ;          TeLNeT : andr01d.zapto.org:9999 [UTC 11:00 - 20:00]            ;
   :          SySoP  : xqtr                   eMAiL: xqtr@gmx.com            :
   [          DoNaTe : https://paypal.me/xqtr                                ]
   `:_______________________________________________________________________;´
     \________________\  No CoPyRiGHT ReSeRVeD - 2018xx    /________________/
        \___\    \______________________________________________/   /___/
                        \________________________________/
