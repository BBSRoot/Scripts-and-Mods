        __  _                        __ _                           _  __
  ______\ \_\\_______________________\///__________________________//_/ /______
  \___\                                                                   /___/
   | .__                                 __                                  |
   | |                   ___  __________/  |________                         |
   |                     \  \/  / ____/\   __\_  __ \                        |
   ;                      >    < <_|  | |  |  |  | \/                        ;
   :                     /__/\_ \__   | |__|  |__|                           :
   .                           \/  |__|      Releases                        .
   .                                                                         .
   :           H/Q Another Droid BBS - andr01d.zapto.org:9999                :
   ;                                                                         ;
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   :                                                                         :
   |                        JAM Base Analyzer v0.2                           |
   :                                                                         :
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   | ._          SoftWare         Oper.System      Type                      |
   ; |           - { } BASH       - {x} Linux      - { } ANSI                ;
   :             - { } DOOR       - {x} RPi        - { } TEXT                :
   .             - { } MPL        - { } Windows    - { } ASCII               .
   :             - { } Python     - { } Mac        - {x} BINARY              :
   ;             - { } Source     - { } OS/2                                 ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   |  _     _ _                                                              |
   ; |    _| | |_    ____  _         _     _                                 ;
   :     |_     _|  |    \|_|___ ___| |___|_|_____ ___ ___                   :
   .     |_     _|  |  |  | |_ -|  _| | .'| |     | -_|  _|   _ _ _          .
   ;       |_|_|    |____/|_|___|___|_|__,|_|_|_|_|___|_|    |_|_|_|         ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   ; The author has taken every precaution to insure that no harm or damage  ;
   | will occur on computer systems operating this util.  Never the less, the:
   ; author will NOT be held liable for whatever may happen on your computer .
   : system or to any computer systems which connects to your own as a result:
   . of. operating this util.  The user assumes full responsibility for the  ;
   : correct operation of this software package, whether harm or damage      |
   ; results from software error, hardware malfunction, or operator error.   :
   | NO warranties are : offered, expressly stated or implied, including     .
   | without limitation or ; restriction any warranties of operation for a   :
   ; particular purpose and/or | merchant ability.  If you do not agree with ;
   : this then do NOT use this program.                                      |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   |        _ _                                                              |
   ;      _| | |_    _____ _           _                                     ;
   :     |_     _|  |  _  | |_ ___ _ _| |_                                   :
   .     |_     _|  |     | . | . | | |  _|   _ _ _                          .
   ;       |_|_|    |__|__|___|___|___|_|    |_|_|_|                         ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   | This is an application to view JAM Base files and also extract text,    |
   ; UUE encoded files and also PGP keys. You can view the headers of the    ;
   : base or for each message and also make searches with regular            :
   . expressions.                                                            .
   :                                                                         :
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   |        _ _                                                              |
   ;      _| | |_    _____         _       _ _                               ;
   :     |_     _|  |     |___ ___| |_ ___| | |                              :
   .     |_     _|  |-   -|   |_ -|  _| .'| | |   _ _ _                      .
   ;       |_|_|    |_____|_|_|___|_| |__,|_|_|  |_|_|_|                     ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   | No Installation... Just execute it.                                     |
   ;                                                                         ;
   .                                                                         .
   ;                                                                         ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   |        _ _                                                              |
   ;      _| | |_    _____         ___ _                                     ;
   :     |_     _|  |     |___ ___|  _|_|___                                 :
   .     |_     _|  |   --| . |   |  _| | . |   _ _ _                        .
   ;       |_|_|    |_____|___|_|_|_| |_|_  |  |_|_|_|                       ;
   |                                    |___|                                |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   | No need to configure anything...                                        |
   ;                                                                         ;
   :                                                                         :
   ;                                                                         ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   |        _ _                                                              |
   ;      _| | |_    _____                                                   ;
   :     |_     _|  |  |  |___ ___                                           :
   .     |_     _|  |  |  |_ -| -_|   _ _ _                                  .
   ;       |_|_|    |_____|___|___|  |_|_|_|                                 ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   | You can execute it like:  ./jaman  or provide a JAM base file to open   |
   ; like:  ./jaman jambase.jdx. The extension of the file doesn't matter.   ;
   :                                                                         :
   . Press H for further help. There are various commands you can give       .
     inside the application.
   .                                                                         .
   :                                                                         :
   ;                                                                         ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   |        _ _                                                              |
   ;      _| | |_    _____ _ _                                               ;
   :     |_     _|  |   __|_| |___ ___                                       :
   .     |_     _|  |   __| | | -_|_ -|   _ _ _                              .
   ;       |_|_|    |__|  |_|_|___|___|  |_|_|_|                             ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   | jaman_rpi                                                               |
   ; jaman_l32                                                               ;
   : help.ans                                                                :
   . file_id.diz                                                             .
     readme.txt
   .                                                                         .
   :                                                                         :
   ;                                                                         ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   |        _ _                                                              |
   ;      _| | |_    _____ _     _                                           ;
   :     |_     _|  |  |  |_|___| |_ ___ ___ _ _                             :
   .     |_     _|  |     | |_ -|  _| . |  _| | |   _ _ _                    .
   ;       |_|_|    |__|__|_|___|_| |___|_| |_  |  |_|_|_|                   ;
   |                                        |___|                            |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   | First Release...  05/2018 - Version 0.1                                 |
   ; Second Release    06/2018 - Version 0.2                                 ;
   :      - Added LastRead Msg. Info Feature                                 :
   .      - Added Delete Msg Feature                                         .
          - Show Msg Flags, when displaying Message Header
   .      - Fixed some bugs                                                  .
   :                                                                         :
   ;                                                                         ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   |        _ _                                                              |
   ;      _| | |_    _____           _ _ _                                   ;
   :     |_     _|  |     |___ ___ _| |_| |_ ___                             :
   .     |_     _|  |   --|  _| -_| . | |  _|_ -|   _ _ _                    .
   ;       |_|_|    |_____|_| |___|___|_|_| |___|  |_|_|_|                   ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   | To all BBS lovers outhere who keep the scene alive!!!!                  |
   ;                                                                         ;
   :                                                                         :
   .                                                                         .

   .                                                                         .
   :                                                                         :
   ;                                                                         ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   |        _ _                                                              |
   ;      _| | |_    _____         _           _                             ;
   :     |_     _|  |     |___ ___| |_ ___ ___| |_                           :
   .     |_     _|  |   --| . |   |  _| .'|  _|  _|   _ _ _                  .
   ;       |_|_|    |_____|___|_|_|_| |__,|___|_|    |_|_|_|                 ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   | ._                                                                   _, |
   ; |        _____         _   _              ____          _   _         | ;
   :         |  _  |___ ___| |_| |_ ___ ___   |    \ ___ ___|_|_| |          :
   .         |     |   | . |  _|   | -_|  _|  |  |  |  _| . | | . |          .
   '         |__|__|_|_|___|_| |_|_|___|_|    |____/|_| |___|_|___|          '
                     DoNt Be aNoTHeR DrOiD fOR tHe SySteM                     
                                                                             '
   `  /: HaM RaDiO     /: ANSi ARt!       /: MySTiC MoDS     /: DooRS         
      /: NeWS          /: WeATheR         /: FiLEs           /: SPooKNet     `
   '  /: GaMeS         /: TeXtFiLeS       /: PrEPardNeSS     /: FsxNet       '
      /: TuTors        /: bOOkS/PdFs      /: SuRVaViLiSM     /: ArakNet       
   .                                                                         .
   ;          TeLNeT : andr01d.zapto.org:9999 [UTC 11:00 - 20:00]            ;
   :          SySoP  : xqtr                   eMAiL: xqtr@gmx.com            :
   |          DoNaTe : https://paypal.me/xqtr                                |
   `:_______________________________________________________________________;´
     \________________\  No CoPyRiGHT ReSeRVeD - 2018xx    /________________/
        \___\    \______________________________________________/   /___/
                        \________________________________/

