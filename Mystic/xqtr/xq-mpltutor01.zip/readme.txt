                                          ___              
                             ,----.     ,--.'|_            
                            /   /  \-.  |  | :,'   __  ,-. 
                 ,--,  ,--,|   :    :|  :  : ' : ,' ,'/ /| 
                 |'. \/ .`||   | .\  ..;__,'  /  '  | |' | 
                 '  \/  / ;.   ; |:  ||  |   |   |  |   ,' 
                  \  \.' / '   .  \  |:__,'| :   '  :  /   
                   \  ;  ;  \   `.   |  '  : |__ |  | '    
                  / \  \  \  `--'""| |  |  | '.'|;  : |    
                ./__;   ;  \   |   | |  ;  :    ;|  , ;    
                |   :/\  \ ;   |   | :  |  ,   /  ---'     
                `---'  `--`    `---'.|   ---`-'            
                                 `---`                                  7/2016
------------------------------------------------------------------------------
    __  _______  __       ______      __             _       __    
   /  |/  / __ \/ /      /_  __/_  __/ /_____  _____(_)___ _/ /____
  / /|_/ / /_/ / /        / / / / / / __/ __ \/ ___/ / __ `/ / ___/
 / /  / / ____/ /___     / / / /_/ / /_/ /_/ / /  / / /_/ / (__  ) 
/_/  /_/_/   /_____/    /_/  \__,_/\__/\____/_/  /_/\__,_/_/____/  
                                                                   
------------------------------------------------------------------------------

This is Part 1 of a series of Mystic Programming Language (MPL). The tutors
are compatible with Mystic BBS 1.12+

The set contains the following tutorials:

.. Text Files Basics
.. Record Files Basics
.. Screen Handling
.. Find and List Files
.. Filebase Manipulation

The code from the tutorials are tested under Linux (Ubuntu 14.04) with Mystic
BBS 1.12A26+ and works fine. If you are a Windows user, you may have to do 
some changes.

------------------------------------------------------------------------------
   ______              ___ __      
  / ____/_______  ____/ (_) /______
 / /   / ___/ _ \/ __  / / __/ ___/
/ /___/ /  /  __/ /_/ / / /_(__  ) 
\____/_/   \___/\__,_/_/\__/____/  
                                   

Credits goes to:
... g00r00, programmer of Mystic BBS
... Mystic Guy (Avon) sysop of Agency BBS and moderator of fsxNet
... Gryphon, sysop of Cyberia BBS, for his great coding work in MPL
... To all those that keep BBSes alive!!!

