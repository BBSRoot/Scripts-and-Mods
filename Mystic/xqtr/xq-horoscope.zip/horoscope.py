#!/usr/bin/python

   #horoscope.py
   
   #Copyright 2017 xqtr (xqtr.xqtr@gmail.com)
   
   #This program is free software; you can redistribute it and/or modify
   #it under the terms of the GNU General Public License as published by
   #the Free Software Foundation; either version 2 of the License, or
   #(at your option) any later version.
   
   #This program is distributed in the hope that it will be useful,
   #but WITHOUT ANY WARRANTY; without even the implied warranty of
   #MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   #GNU General Public License for more details.
   
   #You should have received a copy of the GNU General Public License
   #along with this program; if not, write to the Free Software
   #Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
   #MA 02110-1301, USA.
   
   #_            _   _              ___          _    _       
  #/_\  _ _  ___| |_| |_  ___ _ _  |   \ _ _ ___(_)__| |               8888
 #/ _ \| ' \/ _ \  _| ' \/ -_) '_| | |) | '_/ _ \ / _` |            8 888888 8
#/_/ \_\_||_\___/\__|_||_\___|_|   |___/|_| \___/_\__,_|            8888888888
                                                                   #8888888888
         #DoNt Be aNoTHeR DrOiD fOR tHe SySteM                      88 8888 88
                                                                   #8888888888
    #.o HaM RaDiO    .o ANSi ARt!       .o MySTiC MoDS              "88||||88"
    #.o NeWS         .o WeATheR         .o FiLEs                     ""8888""
    #.o GaMeS        .o TeXtFiLeS       .o PrEPardNeSS                  88
    #.o TuTors       .o bOOkS/PdFs      .o SuRVaViLiSM          8 8 88888888888
    #.o FsxNet       .o SurvNet         .o More...            888 8888][][][888
                                                               #8 888888##88888
   #TeLNeT : andr01d.zapto.org:9999 [UTC 11:00 - 20:00]         8 8888.####.888
   #SySoP  : xqtr                   eMAiL: xqtr.xqtr@gmail.com  8 8888##88##888
   #DoNaTe : https://paypal.me/xqtr



import urllib
import sys
import os
from bs4 import BeautifulSoup
#from pycrt import *
import textwrap
import tty,termios
import time

class colors:
    #Colors class:
    #reset all colors with colors.reset
    #two subclasses fg for foreground and bg for background.
    #use as colors.subclass.colorname.
    #i.e. colors.fg.red or colors.bg.green
    #also, the generic bold, disable, underline, reverse, strikethrough,
    #and invisible work with the main class
    #i.e. colors.bold

    reset='\033[0m'
    bold='\033[01m'
    disable='\033[02m'
    underline='\033[04m'
    reverse='\033[07m'
    strikethrough='\033[09m'
    invisible='\033[08m'
    class fg:
        black='\033[30m'
        red='\033[31m'
        green='\033[32m'
        orange='\033[33m'
        blue='\033[34m'
        purple='\033[35m'
        cyan='\033[36m'
        lightgrey='\033[37m'
        darkgrey='\033[90m'
        lightred='\033[91m'
        lightgreen='\033[92m'
        yellow='\033[93m'
        lightblue='\033[94m'
        pink='\033[95m'
        lightcyan='\033[96m'
    class bg:
        black='\033[40m'
        red='\033[41m'
        green='\033[42m'
        orange='\033[43m'
        blue='\033[44m'
        purple='\033[45m'
        cyan='\033[46m'
        lightgrey='\033[47m'
        
def clrscr():
    sys.stdout.write('\033[2J')
#   n=0 clears from cursor until end of screen,
#   n=1 clears from cursor to beginning of screen
#   n=2 clears entire screen
    sys.stdout.flush()
        
def readkey():
    ch1=''
    ch2=''
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin.fileno())
        ch = sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return ch
        
def cls():
    os.system('cls' if os.name == 'nt' else 'clear')
    
def ansi_on():
    sys.stdout.write('\033(U\033[0m')
    sys.stdout.flush()

url_base = 'http://www.astrology.com/horoscope/daily/'

#https://www.astrology.com/horoscope/daily/taurus.html

def dailyHoroscope(resp):
    global b
    url = url_base + resp.lower() + '.html'
    html_read = urllib.urlopen(url)
    soup = BeautifulSoup(html_read,'html.parser')

    forDate = soup.find('h6',{'class':'date'}).text
    dailyPrediction = soup.find('p').text
    
    datestr="Horoscope for Date: "+forDate
    print 
    print colors.fg.green+datestr.center(79,' ')+colors.reset
    print 
    print colors.fg.yellow+desc.center(79,' ')+colors.reset
    b=int(b)
    print 
    
    print colors.fg.lightcyan+str1.center(79,' ')
    print str2.center(79,' ')
    print str3.center(79,' ')
    print str4.center(79,' ')
    print str5.center(79,' ')
    print str6.center(79,' ')+colors.reset

    print colors.fg.lightblue
    #body = '\n'.join(['\n'.join(textwrap.wrap(dailyPrediction , 90, break_long_words=False, replace_whitespace=False))
    #for line in body.splitlines() if line.strip() != ''])
    body=textwrap.fill(dailyPrediction, 79)
    print (body)
    print colors.reset


ansi_on()
clrscr()

if len(sys.argv) < 3:
    a=time.strftime("%d")
    b=time.strftime("%m")
else:
    a = sys.argv[1]
    b = sys.argv[2]

d = int(a)
m = int(b)

if m == 1:
    if d >= 19:
        sign = 'capricorn'
        desc = 'Capricorn  -  The Goat'
        str1="        _  "
        str2="\      /_) "
        str3=" \    /'.  "
        str4="  \  /   : "
        str5="   \/ __.' "
        str6=""
    else:
        sign = 'aquarius'
        desc = 'Aquarius  -  The Water Bearer'
        str1=""
        str2=""
        str3='.-"-._.-"-._.- '
        str4='.-"-._.-"-._.- '
        str5=""
        str6=""
elif m == 2:
    if d >= 19:
        sign = 'pisces'
        desc = 'Pisces  -  The Fishes'
        str1="'-.    .-' "
        str2="   :  :    "
        str3=" --:--:--  "
        str4="   :  :    "
        str5=".-'    '-. "
        str6=""
    else:
        sign = 'aquarius'
        desc = 'Aquarius  -  The Water Bearer'
        str1=""
        str2=""
        str3='.-"-._.-"-._.- '
        str4='.-"-._.-"-._.- '
        str5=""
        str6=""
elif m == 3:
    if d >= 21:
        sign = 'aries'
        desc = 'Aries  -  The Ram'
        str1="            "
        str2=" .-.   .-.  "
        str3="(_  \ /  _) "
        str4="     |      "
        str5="     |      "
        str6="            "
    else:
        sign = 'pisces'
        desc = 'Pisces  -  The Fishes'
        str1="'-.    .-' "
        str2="   :  :    "
        str3=" --:--:--  "
        str4="   :  :    "
        str5=".-'    '-. "
        str6=""
elif m == 4:
    if d >= 20:
        sign = 'taurus'
        desc = 'Taurus  -  The Bull'
        str1=" .     .  "
        str2=" '.___.'  "
        str3=" .'   '.  "
        str4=":       : "
        str5=":       : "
        str6=" '.___.'  "
    else:
        sign = 'aries'
        desc = 'Aries  -  The Ram'
        str1="            "
        str2=" .-.   .-.  "
        str3="(_  \ /  _) "
        str4="     |      "
        str5="     |      "
        str6="            "
elif m == 5:
    if d >= 21:
        sign = 'gemini'
        desc = 'Gemini  -  The Twins'
        str1="._____.  "
        str2="  | |    "
        str3="  | |    "
        str4=" _|_|_   "
        str5="'     '  "
        str6=""
    else:
        sign = 'taurus'
        desc = 'Taurus  -  The Bull'
        str1=" .     .  "
        str2=" '.___.'  "
        str3=" .'   '.  "
        str4=":       : "
        str5=":       : "
        str6=" '.___.'  "
elif m == 6:
    if d >= 21:
        sign = 'cancer'
        desc = 'Cancer  -  The Crab'
        str1="   .--.   "
        str2="  /   _'. "
        str3=" (_) ( )  "
        str4="'.    /   "
        str5="  '--'    "
        str6=""
    else:
        sign = 'gemini'
        desc = 'Gemini  -  The Twins'
        str1="._____.  "
        str2="  | |    "
        str3="  | |    "
        str4=" _|_|_   "
        str5="'     '  "
        str6=""
elif m == 7:
    if d >= 23:
        sign = 'leo'
        desc = 'Leo  -  The Lion'
        str1=""
        str2="  .--.   "
        str3=" (    )  "
        str4="(_)  /   "
        str5="    (_.  "
        str6=""
    else:
        sign = 'cancer'
        desc = 'Cancer  -  The Crab'
        str1="   .--.   "
        str2="  /   _'. "
        str3=" (_) ( )  "
        str4="'.    /   "
        str5="  '--'    "
        str6=""
elif m == 8:
    if d >= 23:
        sign = 'virgo'
        desc = 'Virgo  -  The Virgin'
        str1=" _           "
        str2="' ':--.--.   "
        str3="   |  |  |_  "
        str4="   |  |  | ) "
        str5="   |  |  |/  "
        str6="        (J   "
    else:
        sign = 'leo'
        desc = 'Leo  -  The Lion'
        str1=""
        str2="  .--.   "
        str3=" (    )  "
        str4="(_)  /   "
        str5="    (_.  "
        str6=""
elif m == 9:
    if d >= 23:
        sign = 'libra'
        desc = 'Libra  -  The Balance'
        str1=""
        str2="     __      "
        str3="___.'  '.___ "
        str4="____________ "
        str5=""
        str6=""
    else:
        sign = 'virgo'
        desc = 'Virgo  -  The Virgin'
        str1=" _           "
        str2="' ':--.--.   "
        str3="   |  |  |_  "
        str4="   |  |  | ) "
        str5="   |  |  |/  "
        str6="        (J   "
elif m == 10:
    if d >= 23:
        sign = 'scorpio'
        desc = 'Scorpius  -  The Scorpion'
        str1=" _              "
        str2="' ':--.--.      "
        str3="   |  |  |      "
        str4="   |  |  |      "
        str5="   |  |  |  ... "
        str6="         '---': "
    else:
        sign = 'libra'
        desc = 'Libra  -  The Balance'
        str1=""
        str2="     __      "
        str3="___.'  '.___ "
        str4="____________ "
        str5=""
        str6=""
elif m == 11:
    if d >= 22:
        sign = 'sagittarius'
        desc = 'Sagittarius  -  The Archer'
        str1="      ... "
        str2="      .': "
        str3="    .'    "
        str4="'..'      "
        str5=".''.      "
        str6="          "
    else:
        sign = 'scorpio'
        desc = 'Scorpius  -  The Scorpion'
        str1=" _              "
        str2="' ':--.--.      "
        str3="   |  |  |      "
        str4="   |  |  |      "
        str5="   |  |  |  ... "
        str6="         '---': "
elif m == 12:
    if d >= 22:
        sign = 'capricorn'
        desc = 'Capricorn  -  The Goat'
        str1="        _  "
        str2="\      /_) "
        str3=" \    /'.  "
        str4="  \  /   : "
        str5="   \/ __.' "
        str6=""
    else:
        sign = 'sagittarius'
        desc = 'Sagittarius  -  The Archer'
        str1="      ... "
        str2="      .': "
        str3="    .'    "
        str4="'..'      "
        str5=".''.      "
        str6="          "
        
dailyHoroscope(sign)
print colors.fg.lightgrey+'Press a key to continue...'
readkey()

